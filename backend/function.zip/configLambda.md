#Install serverless-http

#export in last line: module.exports.handler = serverless(app);

#Create lambda function
    #simple create
    #add environment variables

#Create API-Gateway
    #Create api http
        #Config integration with lambda function
        #config end point 'any/{proxy+}'
    
    #Create api rest
        #create a simple api rest
        #create resource with proxy '/{proxy+}'  //proxy is using to allow use routes
        #create methods
            #I need create each method that i will use in my system. (POST, GET, PUT, DELETE...)
            #Remember configure integration with my function lambda


